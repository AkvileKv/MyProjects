#include<iostream>
#include <fstream>

using namespace std;

void paemimas (int sk, int sk2, int n);
void Dijkstra(int sk, int sk2, int n);
void spausd(int sk, int sk2, int n);

int m, a, b,k; // n - eil. ir stulp. skaicius masyve, mano atveju 6;
// k skirtas saugoti minP pozicijai;
int mas[6][6]; // reikia daugiau vietos issiskirti, o ne tik 6 !!!
int D[6], P[6], S[6]; //globalus, nereikia siuntineti funkcijomis;



int main()
{

    int sk, sk2, n;

     cout<<"Iveskite virsuniu skaiciu"<<endl;
    cin>>n;
    cout<<endl;

    cout<<"Iveskite pradzios virsune nuo 1 iki 6"<<endl;
    cin>>sk;
    cout<<endl;

    cout<<"Iveskite pabaigos virsune nuo 1 iki 6"<<endl;
    cin>>sk2;
    cout<<endl;

    if (sk<1 || sk>n || sk2<1 || sk2>n || sk==sk2)
    {
        cout <<"Pasirinkimas negalimas"<<endl;
    }
    else
    {
//-----------------masyvo nuskaitymas----------------
        ifstream fd("grafas.txt");        //skaitymui is failo;
        fd>>n; // fd - tas pats kaip cin; n ir n, nes bus vienodas skaiciuseiluciu ir stulpeliu;

        for (int i=0; i<n; i++)
        {
            for (int j=0; j<n; j++)
            {
                fd>>mas[i][j];
            }
        }
        fd.close(); // failas uzdaromas PO duomenu nuskaitymo;

        paemimas (sk, sk2, n);
        Dijkstra (sk, sk2, n);
        spausd (sk, sk2, n);

    }
    return 0;
}

void paemimas (int sk, int sk2, int n)
{
//---------------D eilute paima-------------
    for (int j=0; j<n; j++)
    {
        D[j]=mas[sk-1][j];
        // cout<<mas[sk-1][j]<<" ";
    }
    cout<<"D pradine aibe: "<<" ";
    for (int j=0; j<n; j++)
    {
        cout<<D[j]<<" "; //D masyvas;
    }
    cout<<endl;

//-----------S aibe sudaroma--------------
    for (int j=0; j<n; j++)
    {
        S[j]=j;
    }
    S[sk-1]=-8; // pirmoji i S aibe itraukta virsune pazymima kaip -8;

    cout<<"S pradine aibe: "<<" ";
    for (int j=0; j<n; j++)
    {
        cout<<S[j]<< " ";
    }
    cout<<endl;

//---------pradine P aibe sudaroma---------
    for (int j=0; j<n; j++)
    {
        P[j]=sk;
    }
    cout<<"P pradine aibe: "<<" ";
    for (int j=0; j<n; j++)
    {
        cout<<P[j]<< " "; // P aibe su pradinem reiksmem;
    }
    cout<<endl;
    cout<<endl;

}

void Dijkstra (int sk, int sk2,int n)
{
    for (int iteracija=1; iteracija<n; iteracija++)
    {
//--------------Dijkstra--------------------------
//-----------------------1.suranda min--------------

        int minR=9999; //minimumas;
        int minP=0; // min reiksmes pozicija masyve [0,1,2,3,4,5];

        for (int j=0; j<n; j++) // tikrina visa masyva judedamas 'stulpeliais'
        {
            if (S[j] == -8)
            {
                continue;
            }
            if (minR > D[j] && D[j]>0) //lyginu, ar minX didesne uz masyvo elementa;
            {
                minR=D[j]; // reiksme minimumo;
                minP=j; // pozicija;
            }
        }
        // cout<<"Pozicija masyve: "<<minP+1<<endl;
        cout<<endl;

        S[minP]=-8; //minP pozicija S aibej taps i -8;
        k=minP; // k skirtas saugoti minP pozicijai;

//--------------------2.skaiciuoja kelia-----------
        for (int j=0; j<n; j++) // tikrina visa masyva judedamas 'stulpeliais'
        {
            if (mas[minP][j] < 0)
            {
                continue;
            }
            if (D[j] < 0) // jei -1 (begalybe);
            {
                D[j] = minR + mas[minP][j];
                P[j]= k+1;
                continue;
            }
            if ((D[minP] + mas[minP][j]) < D[j]) //jei skaicius teigiamas
            {
                D[j] = minR + mas[minP][j];
                P[j]= k+1;
            }
        }
        cout << "i= " << iteracija << endl;
        cout << endl;

        cout << "D = " <<" ";

        for (int j=0; j<n; j++)
        {
            if (D[j]==9999)
            {
                cout <<D[j]<<" ";
                continue;
            }
            cout <<D[j]<< " ";
        }

        cout << endl;
        cout << "S = " <<" ";

        for (int j=0; j<n; j++)
        {
            cout <<S[j]<< " ";
        }

        cout << endl;
        cout << "P = " <<" ";
        for (int j=0; j<n; j++)
        {
            cout <<P[j]<< " ";
        }
        cout << endl;

//------------------------------------------
        cout << endl;
        cout << endl;
//--------------------------
        if (D[sk2-1]==9999)
        {
            cout <<"Nuo "<<sk<<" iki "<<sk2<<" virsunes: "<<"kelio nera"<< " ";
        }
        else
        {
            cout <<"Atstumas nuo "<<sk<<" iki "<<sk2<<" virsunes: "<<D[sk2-1]<< " ";
        }
    }

}

void spausd(int sk, int sk2, int n)
{
//---------------Duomenu irasymas i faila---------------------

    ofstream failas("P.value.txt"); // failas, i kuri irasysiu duomenis;

    if (D[sk2-1]==9999)
    {

    }
    else
    {
        cout << endl;
        //cout << "P kelias = " <<" ";
        for (int j=sk2-1; P[j]!=sk; )
        {
            //cout <<P[j]<<" ";
            failas<<P[j]; // irasau i tekstini faila duomenis;

            j=P[j]-1;
        }
        failas.close();
        cout << endl;
        cout << endl;
//-----------------------------------------
        cout<<"Virsunes, per kurias eina kelias: "<<endl;
        string an; // duomenys is mano tekstinio failo;
        ifstream fd2("P.value.txt");
        fd2>>an;
        fd2.close();

        an=string(an.rbegin(),an.rend()); // pradzia sukeicia su pabaiga;
        cout<<sk;
        cout<<an;
        cout<<sk2;

        cout << endl;
    }

//-----------masyvo spausdinimas-----------
    cout<<endl;
    cout << endl;
    cout << endl;
    for (int i=0; i<n; i++)
    {
        for (int j=0; j<n; j++)
        {
            cout<<mas[i][j]<<" ";
        }
        cout<<endl;
    }
//-----------------------------------------
}
