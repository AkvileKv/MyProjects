﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;

namespace SecondThreads
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       // ManualResetEvent resetEvent = new ManualResetEvent(true);

        public MainWindow()
        {
            InitializeComponent();
        }

        private void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog fBrowserD = new FolderBrowserDialog();
            DialogResult searchingResult = fBrowserD.ShowDialog();
            StartPointNameTextBox.Text = fBrowserD.SelectedPath; //laukas igauna pasirinkto kelio reiksme 
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            ResultListView.Items.Clear();
            FileNameTextBox.Clear();
            StartPointNameTextBox.Clear();
            ProgressBar.Value = 0;       
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            ResultListView.Items.Clear(); //isvalau rezultatus
           
                if (FileNameTextBox.Text == "" || StartPointNameTextBox.Text == "")//ar laukai ne tusti
                {
                    MessageBox.Show("Please fill in all fields");
                    return;
                }
                if (!Directory.Exists(StartPointNameTextBox.Text)) //ar egzistuoja direktorija
                {
                    MessageBox.Show("Selected directory does not exist...");
                    return;
                }
                if (FileRadioButton.IsChecked.Value.Equals(true) && EncryptRadioButton.IsChecked.Value.Equals(true)) // FAILU paieskai
                {
                 ResultListView.Visibility = Visibility.Visible;

                List<string> list1 = SearchingForThemFiles(StartPointNameTextBox.Text); //pereina per visus (kiek is viso failu yra tenai)
                Search toSearch = new Search(FileNameTextBox, StartPointNameTextBox, ResultListView, 
                               SearchButton, ProgressBar, list1, EncryptRadioButton, DecryptRadioButton);

                Thread th = new Thread(new ThreadStart(toSearch.GetFiles)); //Kuriama gija failu paieskai ir kodavimui, deleguojamas metodas
               // th.IsBackground = true;
                th.Start();
                }
                else if (FileRadioButton.IsChecked.Value.Equals(true) && DecryptRadioButton.IsChecked.Value.Equals(true))
            {    
                ResultListView.Visibility = Visibility.Hidden;

                List<string> list1 = SearchingForThemFiles(StartPointNameTextBox.Text); //pereina per visus (kiek is viso failu yra tenai)
                Search toSearch = new Search(FileNameTextBox, StartPointNameTextBox, ResultListView,
                           SearchButton, ProgressBar, list1, EncryptRadioButton, DecryptRadioButton);

                Thread th = new Thread(new ThreadStart(toSearch.GetFiles)); //Kuriama gija failu paieskai ir dekodavimui, deleguojamas metodas
                th.Start();
            }
        }

        //-------------pereina per visus FAILUS--------------
        static public List<string> SearchingForThemFiles(string path1) //ieskant failu
        {
            List<string> resultList = new List<string>(); //sukuriamas rezultatu list'as string tipo 
            string pathh = "";

            try
            {
                foreach (var item in Directory.GetFiles(path1)) //pradzios direktorijoj failu ieskoti
                {
                    resultList.Add(item); //pridedu i resultList rastus
                }
                foreach (var item in Directory.GetDirectories(path1)) //subdirektoriju vardai direktorijoj
                {
                    foreach (var file in SearchingForFiles(item)) //subdirektorijose ieskoti failu
                    {
                        resultList.Add(file); //pridedu i resultList rastus
                    }
                    pathh = item; //subdirektoriju vardai tampa pathh
                }

                foreach (var item in Directory.GetDirectories(pathh)) //subdirektoriju vardai direktorijoj
                {
                    foreach (var file in SearchingForFiles(item))  //subdirektorijose ieskoti failu
                    {
                        resultList.Add(file); //pridedu i resultList rastus
                    }
                }
            }
            catch (Exception)
            {
            }
            return resultList;
        }

        static public List<string> SearchingForFiles(string path1) //subdirektorijose ieskoti failu
        {
            List<string> resultList = new List<string>();

            try
            {
                foreach (var item in Directory.GetFiles(path1))  //visu failu ieskoti
                {
                    resultList.Add(item); //pridedu i resultList rastus
                }
            }

            catch (Exception)
            {
            }
            return resultList;
        }

       private void PauseButton_Click(object sender, RoutedEventArgs e)
        {
          //  resetEvent.Reset();
        } 

        private void ResumeButton_Click(object sender, RoutedEventArgs e)
        {
          //  resetEvent.Set();
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
