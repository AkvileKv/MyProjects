﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Threading;

namespace SecondThreads
{
    class AddToList
    {
        Information resultPath; //rezultatu isvedimui reiks
        ListView resultList;

        public AddToList(ListView resultList, Information resultPathPath) //konstruktorius
        {
            this.resultList = resultList;
            this.resultPath = resultPathPath;
        }

        public void ListAdd()
        {
            resultList.Dispatcher.Invoke(() =>
            {                                                                              //Dispatcher-darbui su gijomis valdyti, prioritetiniam 
                resultList.Items.Add(resultPath);                                          //ju darbui. Invoke - vykdoma nedelsiant
                resultList.Dispatcher.Invoke(DispatcherPriority.Render, EmptyDelegate);
            }                                                                              //Render - Operacijos, apdorojamos tuo pačiu prioritetu, 
                );                                                                         //kaip ir pateikiamos.
        }
        private static Action EmptyDelegate = delegate () { };
    }
}
