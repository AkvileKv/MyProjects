﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;

using System.Windows.Threading;

namespace SecondThreads
{
    class Search
    {
        ManualResetEvent resetEvent = new ManualResetEvent(true);

        private static string key = "ikksotqrwsndirtqqlklpffexmjtebpq"; //32
        private static string IV = "juiosdtysmckqols"; //16
        string filePathMD5 = "C:\\Users\\Akvilė\\Desktop\\FileMD5.txt";      

        TextBox FileNameTextBox;
        TextBox StartPointNameTextBox;
        ListView ResultListView;
        Button SearchButton;
        ProgressBar ProgressBar;
        List<string> list1 = new List<string>();
        RadioButton EncryptRadioButton;
        RadioButton DecryptRadioButton;
        

        public Search(TextBox fileNameTextBox, TextBox startPointNameTextBox,
            ListView resultListView, Button searchButton, ProgressBar progressBar,
            List<string> list1, RadioButton encryptRadioButton, RadioButton decryptRadioButton)
        {
            FileNameTextBox = fileNameTextBox;
            StartPointNameTextBox = startPointNameTextBox;
            ResultListView = resultListView;
            SearchButton = searchButton;
            ProgressBar = progressBar;
            this.list1 = list1;
            EncryptRadioButton = encryptRadioButton;
            DecryptRadioButton = decryptRadioButton;          
        }

        public void GetFiles()
        {
            ResultListView.Dispatcher.Invoke(() =>             //rodykline anonimine f-ja. Sukuriamas metodas
            {                                                  //Dispatcher-darbui su gijomis valdyti, prioritetiniam ju darbui. Invoke - vykdoma nedelsiant
                var chronometer = new Stopwatch();
               // MessageBox.Show("Execution was successfully");
                chronometer.Start();

                ProgressBar.Value = 0;
                ProgressBar.Maximum = list1.Count;  //listo su rastais failais
                ProgressBar.Visibility = Visibility.Visible;

                FileSearching(StartPointNameTextBox.Text, ProcessFile, list1); //paieska vykdoma
                chronometer.Stop(); //baigesi paieska, sustoja chronometras 
                
                MessageBox.Show("Execution was successfully");
                var elapsedTime = chronometer.ElapsedMilliseconds;
                MessageBox.Show("Execution time: " + (elapsedTime / 1).ToString() + " ms");               
            });
        }

        static void ProcessFile(string path) { }

        //----------------------bendram liste1 iesko mano FAILO---------------
        public void FileSearching(string path1, Action<string> fAction, List<string> list1)
        {
            foreach (var item in Directory.GetFiles(path1))  //pradzios direktorijoj failu ieskoti
            {
                try
                {
                    ResultListView.Dispatcher.Invoke(() =>                //rodykline anonimine f-ja. Sukuriamas metodas
                    {      //Dispatcher-darbui su gijomis valdyti, prioritetiniam ju darbui. Invoke - vykdoma nedelsiant

                        if (list1.Contains(item))   //Ar ieskomas failas yra list1'e
                        {
                            ProgressBar.Dispatcher.Invoke(() =>
                            ProgressBar.Value++, DispatcherPriority.Background);
                        }     //DispatcherPriority - Describes the priorities at which operations can be invoked by way of the Dispatcher;
                              //Background - Operations are processed after all other non-idle operations are completed.

                        if (item.EndsWith(FileNameTextBox.Text)) // Rado 
                        {
                            if (EncryptRadioButton.IsChecked.Value.Equals(true))
                            {                              
                              /*  Thread th1 = new Thread(() => EncryptFile(item, key)) ; //Kuriama gija failu paieskai ir de-kodavimui, deleguojamas metodas
                                th1.IsBackground = true; // galiu sustabdyti
                                th1.Start();                 */             
                               
                               EncryptFile(item, key); //užkoduoja 
                                HashMD5(item); //iraso MD5 Hash i faila
                            
                               //resetEvent.WaitOne();
                            }
                            else if (DecryptRadioButton.IsChecked.Value.Equals(true))
                            {
                                FindHashMD5(item);                                     
                            }       
                            
                            Information information = new Information(item); //kai tik randa faila, pasirodo resultList'e
                            AddToList add = new AddToList(ResultListView, information);

                           // add.ListAdd(); //Jei nenaudojant gijos
                           Thread th = new Thread(add.ListAdd);    //kuriama gija duomenu atvaizdavimui ir isvedimui. 
                           th.Start();                            //Metodas deleguojamas gijai
                        }
                    });  

                }
                catch (Exception)
                {
                }
                fAction(item);
            }
            foreach (var item in Directory.GetDirectories(path1)) //subdirektoriju vardai direktorijoj
            {
                try
                {
                    FileSearching(item, fAction, list1); //rekursiškai kreipiasi i save, paieška subkategorijose
                }
                catch (Exception)
                {
                }
            }
        }
//----------------------------------Encrypt / Decrypt----------------------------------------------------
        private void EncryptFile(string item, string key) //ENCRYPTION
        {  

            byte[] plaintextBytes = File.ReadAllBytes(item); //byte nuskaitymui is failo
           
            // Dispatcher.Invoke(() =>
           // {                                                                              //Dispatcher-darbui su gijomis valdyti, prioritetiniam 
                                                                                        //ju darbui. Invoke - vykdoma nedelsiant                                  
            using (var AES = new AesCryptoServiceProvider()) //Inicializuojama nauja DES algoritmo instancija
            {
                AES.BlockSize = 128;
                AES.KeySize = 256;
                AES.IV = Encoding.ASCII.GetBytes(IV);       //Inicializacijos vektorius simetriniam algoritmui;
                AES.Key = Encoding.ASCII.GetBytes(key);     //Pateikia simbolių kodavimą.
                AES.Mode = CipherMode.ECB;                  //Sifravimo bloko rezimas
                AES.Padding = PaddingMode.PKCS7;            //Uzpildymo tipas, kai pranesimo duomenu blokas yra trumpesnis uz key

                using (var memoryStream = new MemoryStream()) //sukuriamas memoryStream object, kur rezultatas bus saugomas
                {
                    CryptoStream cryptoStream = new CryptoStream(memoryStream, AES.CreateEncryptor(), CryptoStreamMode.Write);
                    //Apibrėžia srautą, kuris susieja duomenų srautus su kriptografinėmis transformacijomis.

                    cryptoStream.Write(plaintextBytes, 0, plaintextBytes.Length); //nuo 0 iki pabaigos
                    cryptoStream.FlushFinalBlock(); //Atnaujina pagrindinį duomenų šaltinį ar saugyklą su dabartine buferio būsena, tada išvalo buferį.
                    File.WriteAllBytes(item, memoryStream.ToArray()); // is memoryStream i faila irasau
                }
            }

               // Dispatcher.Invoke(DispatcherPriority.Render, EmptyDelegate);
           //     resetEvent.WaitOne();  
            //});
        } 
        
        private static Action EmptyDelegate = delegate () { }; 

        private static void DecryptFile(string item, string key) //DECRYPTION
        {
            byte[] encryptedTextBytes = File.ReadAllBytes(item); //byte nuskaitymui is failo

            using (var AES = new AesCryptoServiceProvider()) //Inicializuojama nauja DES algoritmo instancija
            {
                AES.BlockSize = 128;
                AES.KeySize = 256;
                AES.IV = Encoding.ASCII.GetBytes(IV);      //Inicializacijos vektorius simetriniam algoritmui;
                AES.Key = Encoding.ASCII.GetBytes(key);    //Pateikia simbolių kodavimą.
                AES.Mode = CipherMode.ECB;                 //Sifravimo bloko rezimas
                AES.Padding = PaddingMode.PKCS7;           //Uzpildymo tipas, kai pranesimo duomenu blokas yra trumpesnis uz key

                using (var memoryStream = new MemoryStream()) //objektas, kur rezultatai bus saugomi
                {
                    CryptoStream cryptoStream = new CryptoStream(memoryStream, AES.CreateDecryptor(), CryptoStreamMode.Write);
                    //Apibrėžia srautą, kuris susieja duomenų srautus su kriptografinėmis transformacijomis.

                    cryptoStream.Write(encryptedTextBytes, 0, encryptedTextBytes.Length); //nuo 0 iki pabaigos
                    cryptoStream.FlushFinalBlock(); //Atnaujina pagrindinį duomenų šaltinį ar saugyklą su dabartine buferio būsena, tada išvalo buferį.
                    File.WriteAllBytes(item, memoryStream.ToArray()); // is memoryStream i faila irasau                 
                }
            }         
        }
//------------------------------------MD5 hash-----------------------------------------------------------
        private void HashMD5(string item) // MD5 Hash apskaiciuoja ir iraso i faila
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(item));
            byte[] textBytes = md5.ComputeHash(File.ReadAllBytes(item)); //byte nuskaitymui is failo

            StringBuilder str = new StringBuilder();
            for (int i = 0; i < textBytes.Length; i++)
            {
                str.Append(textBytes[i].ToString("x2"));
            }
            StreamWriter toFile = new StreamWriter(filePathMD5, true); //kad pridetu teksta, o ne perrasytu
            toFile.Write(str.ToString() + "\n");
           // string md5Value = str.ToString();
            //toFile.Write(md5Value);
            toFile.Close();
        }

        private void FindHashMD5(string item) // MD5 Hash apskaiciavimui ir palyginimui
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(item));
            byte[] textBytes = md5.ComputeHash(File.ReadAllBytes(item)); //byte nuskaitymui is failo

            StringBuilder str = new StringBuilder();
            for (int i = 0; i < textBytes.Length; i++)
            {
                str.Append(textBytes[i].ToString("x2"));
            }
            string md5Value = str.ToString();
            //---------paieska FileMD5 faile ir lyginimas------
            foreach (var line in File.ReadAllLines(filePathMD5))
            {
                if (line.Contains(md5Value))
                {
                    DecryptFile(item, key);
                
                }
                else
                {
                    
                }
            }           
        }


    }
}
