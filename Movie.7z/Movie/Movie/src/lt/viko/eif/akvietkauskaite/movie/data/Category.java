/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

/**
 *
 * @author Akvilė
 */
public class Category {
    
    
    private String categoryName;
    
    private PopularMovie[] popularMovies; //priskiriu filmus kategorijai
    

      
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    
    
}
