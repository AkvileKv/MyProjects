/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

/**
 *
 * @author Akvilė
 */
public class PopularMovie {
    
    public static final char WON_OSCARS = 'W'; // konstantos
    public static final char NO_OSCARS = 'N';
    
    public static final boolean KIDS = true;
    public static final boolean ADULTS = false;
    
    private String title;
    private String category;
    private String releaseDate;
    private String IMDB;
    private int runtime;
    private String director;
    private String stars;    
    private char oscars;
    private boolean forKids;

    public PopularMovie(String title, String category, String releaseDate, String IMDB, int runtime, String director, String stars, char oscars, boolean forKids) {
        this.title = title;
        this.category = category;
        this.releaseDate = releaseDate;
        this.IMDB = IMDB;
        this.runtime = runtime;
        this.director = director;
        this.stars = stars;
        this.oscars = oscars;
        this.forKids = forKids;
    }

    @Override
    public String toString() {
        return "PopularMovie{" + "title=" + title + ", category=" + category + ", releaseDate=" + releaseDate + ", IMDB=" + IMDB + ", runtime=" + runtime + ", director=" + director + ", stars=" + stars + ", oscars=" + oscars + ", forKids=" + forKids + '}';
    }
    

    public PopularMovie() {

    }

    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getIMDB() {
        return IMDB;
    }

    public void setIMDB(String IMDB) {
        this.IMDB = IMDB;
    }

    public int getRuntime() {
        return runtime;
    }

    public void setRuntime(int runtime) {
        this.runtime = runtime;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getStars() {
        return stars;
    }

    public void setStars(String stars) {
        this.stars = stars;
    }

    public char getOscars() {
        return oscars;
    }

    public void setOscars(char oscars) {
        this.oscars = oscars;
    }

    public boolean isForKids() {
        return forKids;
    }

    public void setForKids(boolean forKids) {
        this.forKids = forKids;
    }

    
}
