/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.main;
import java.util.*;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovie;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.KIDS;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.ADULTS;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.WON_OSCARS;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.NO_OSCARS;

/**
 * 
 * 
 *
 * @author Akvilė
 */
public class Movie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        PopularMovie movie = new PopularMovie(); //create an object of type PopularMovie
        
        movie.setTitle("Once Upon a Time ...in Hollywood");
        System.out.println("Movie author: " + movie.getTitle());
        movie.setCategory("Comedy, Drama");
        System.out.println("Category : " + movie.getCategory());
        movie.setReleaseDate("16 August 2019");
        System.out.println("Relase date: " + movie.getReleaseDate());
        movie.setIMDB("7.7");
        System.out.println("IMDB: " + movie.getIMDB());
        movie.setRuntime(161);
        System.out.println("Movie author: " + movie.getRuntime() + " minutes");
        movie.setDirector("Quentin Tarantino");
        System.out.println("Director: " + movie.getDirector());
        movie.setStars("Leonardo DiCaprio, Brad Pitt, Margot Robbie, Emile Hirsch");
        System.out.println("Stars: " + movie.getStars());
        //movie.setOscars('W');
        movie.setOscars(WON_OSCARS);
        System.out.println("Won oscars: " + movie.getOscars());
        //movie.setForKids(false);
        movie.setForKids(ADULTS);       
        System.out.println("For kids: " + movie.isForKids());
        
        PopularMovie movie_1 = new PopularMovie("Jojo Rabbit"," Comedy, Drama", 
        "2020", "8.0", 108, "Taika Waititi", "Roman Griffin Davis, Thomasin McKenzie",
        WON_OSCARS,KIDS);
        
        PopularMovie movie_2 = new PopularMovie("Sonic the Hedgehog","Action, Adventure", 
        "2020", "6.9", 99, " Jeff Fowler", "Ben Schwartz, James Marsden",WON_OSCARS,KIDS);
        
        PopularMovie movie_3 = new PopularMovie("Knives Out", "Comedy, Crime","2019",
        "8.0", 131, "Rian Johnson", " Daniel Craig, Chris Evans",NO_OSCARS, ADULTS);
        
        //System.out.println(movie_1);
       ArrayList<PopularMovie> list = new ArrayList<PopularMovie>();
        
       list.add(movie_1);
       list.add(movie_2);
       list.add(movie_3);

       list.forEach(System.out::println);       
    }
    
}
