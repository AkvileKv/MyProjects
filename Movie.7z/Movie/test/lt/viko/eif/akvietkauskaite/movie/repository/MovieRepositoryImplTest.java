/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.repository;

import java.util.LinkedList;
import java.util.List;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovie;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Akvilė
 */
public class MovieRepositoryImplTest {
    
    private static MovieRepositoryImpl instance;
    
    public MovieRepositoryImplTest() {
        
    }
    
    @BeforeClass
    public static void setUpClass() {
        instance = new MovieRepositoryImpl();
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of fetchAllMovies method, of class MovieRepositoryImpl.
     */
    @Test
    public void testFetchAllMovies() {
        System.out.println("fetchAllMovies");                   
      //  List<PopularMovie> popularMovies = new LinkedList<>();
        List<PopularMovie> result = instance.fetchAllMovies();
        assertEquals(4, result.size());
    }

    /**
     * Test of findOnePopularMovie method, of class MovieRepositoryImpl.
     */
    @Test
    public void testFindOnePopularMovie() {
        System.out.println("findOnePopularMovie");
        int id = 0;
        PopularMovie expResult = null;
        PopularMovie result = instance.findOnePopularMovie(id);
        assertEquals(expResult, result);

    }

    /**
     * Test of updateMovie method, of class MovieRepositoryImpl.
     */
    @Test
    public void testUpdateMovie() {
        System.out.println("updateMovie");
        PopularMovie popularMovie = null;
        instance.updateMovie(popularMovie);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteMovie method, of class MovieRepositoryImpl.
     */
    @Test
    public void testDeleteMovie() {
        System.out.println("deleteMovie");
        int id = 0;
        instance.deleteMovie(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
