/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Akvilė
 */
public class WriterTest {

    private static Writer instance;

    public WriterTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        instance = new Writer();
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getName method, of class Writer.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        String expResult = "Tom";
        instance.setName(expResult);
        String result = instance.getName();
        assertEquals(expResult, result);
    }

    /**
     * Test of setName method, of class Writer.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "Tom";
        instance.setName(name);
    }

    /**
     * Test of getSurname method, of class Writer.
     */
    @Test
    public void testGetSurname() {
        System.out.println("getSurname");
        String expResult = "Vincento";
        instance.setSurname(expResult);
        String result = instance.getSurname();
        assertEquals(expResult, result);
    }

    /**
     * Test of setSurname method, of class Writer.
     */
    @Test
    public void testSetSurname() {
        System.out.println("setSurname");
        String surname = "Vincento";
        instance.setSurname(surname);
    }

    /**
     * Test of getOscarsCount method, of class Writer.
     */
    @Test
    public void testGetOscarsCount() {
        System.out.println("getOscarsCount");
        int expResult = 1;
        instance.setOscarsCount(expResult);
        int result = instance.getOscarsCount();
        assertEquals(expResult, result);
    }

    /**
     * Test of setOscarsCount method, of class Writer.
     */
    @Test
    public void testSetOscarsCount() {
        System.out.println("setOscarsCount");
        int oscarsCount = 1;
        instance.setOscarsCount(oscarsCount);
    }

    /**
     * Test of getWins method, of class Writer.
     */
    @Test
    public void testGetWins() {
        System.out.println("getWins");
        int expResult = 15;
        instance.setWins(expResult);
        int result = instance.getWins();
        assertEquals(expResult, result);
    }

    /**
     * Test of setWins method, of class Writer.
     */
    @Test
    public void testSetWins() {
        System.out.println("setWins");
        int wins = 15;
        instance.setWins(wins);
    }

    /**
     * Test of getNominations method, of class Writer.
     */
    @Test
    public void testGetNominations() {
        System.out.println("getNominations");
        int expResult = 120;
        instance.setNominations(expResult);
        int result = instance.getNominations();
        assertEquals(expResult, result);
    }

    /**
     * Test of setNominations method, of class Writer.
     */
    @Test
    public void testSetNominations() {
        System.out.println("setNominations");
        int nominations = 120;
        instance.setNominations(nominations);
    }

    /**
     * Test of toString method, of class Writer.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        instance.setName("Tom");
        String result = instance.toString();
        assertTrue(result.contains("Tom"));
    }

}
