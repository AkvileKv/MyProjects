/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Akvilė
 */
public class PopularMovieTest {

    private static PopularMovie instance;

    public PopularMovieTest() {

    }

    @BeforeClass
    public static void setUpClass() {
        instance = new PopularMovie();
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of toString method, of class PopularMovie.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        instance.setStars("hello");
        String result = instance.toString();
        assertTrue(result.contains("hello"));
    }

    /**
     * Test of getWriterList method, of class PopularMovie.
     */
    @Test
    public void testGetWriterList() {
        System.out.println("getWriterList");
        Writer writer = new Writer();
        writer.setName("Tom");
        writer.setSurname("Dum");
        instance.getWriterList().add(writer);
        List<Writer> result = instance.getWriterList();
        assertEquals(1, result.size());
        assertTrue(result.contains(writer));
    }

    /**
     * Test of setWriterList method, of class PopularMovie.
     */
    @Test
    public void testSetWriterList() {
        System.out.println("setWriterList");
        List<Writer> writers = new ArrayList();
        Writer writer = new Writer();
        writer.setName("John");
        writer.setSurname("Dum");
        writers.add(writer);
        instance.setWriterList(writers);
        assertEquals(writers, instance.getWriterList());
    }

    /**
     * Test of getTitle method, of class PopularMovie.
     */
    @Test
    public void testGetTitle() {
        System.out.println("getTitle");
        String expResult = "Moon";
        instance.setTitle(expResult);
        String result = instance.getTitle();
        assertEquals(expResult, result);
    }

    /**
     * Test of setTitle method, of class PopularMovie.
     */
    @Test
    public void testSetTitle() {
        System.out.println("setTitle");
        String title = "Moon";
        instance.setTitle(title);
    }

    /**
     * Test of getCategory method, of class PopularMovie.
     */
    @Test
    public void testGetCategory() {
        System.out.println("getCategory");
        String expResult = "Drama";
        instance.setCategory(expResult);
        String result = instance.getCategory();
        assertEquals(expResult, result);
    }

    /**
     * Test of setCategory method, of class PopularMovie.
     */
    @Test
    public void testSetCategory() {
        System.out.println("setCategory");
        String category = "Drama";
        instance.setCategory(category);
    }

    /**
     * Test of getReleaseDate method, of class PopularMovie.
     */
    @Test
    public void testGetReleaseDate() {
        System.out.println("getReleaseDate");
        String expResult = "2020";
        instance.setReleaseDate(expResult);
        String result = instance.getReleaseDate();
        assertEquals(expResult, result);
    }

    /**
     * Test of setReleaseDate method, of class PopularMovie.
     */
    @Test
    public void testSetReleaseDate() {
        System.out.println("setReleaseDate");
        String releaseDate = "2020";
        instance.setReleaseDate(releaseDate);
    }

    /**
     * Test of getIMDB method, of class PopularMovie.
     */
    @Test
    public void testGetIMDB() {
        System.out.println("getIMDB");
        String expResult = "8.5";
        instance.setIMDB(expResult);
        String result = instance.getIMDB();
        assertEquals(expResult, result);
    }

    /**
     * Test of setIMDB method, of class PopularMovie.
     */
    @Test
    public void testSetIMDB() {
        System.out.println("setIMDB");
        String IMDB = "8.5";
        instance.setIMDB(IMDB);
    }

    /**
     * Test of getRuntime method, of class PopularMovie.
     */
    @Test
    public void testGetRuntime() {
        System.out.println("getRuntime");
        int expResult = 150;
        instance.setRuntime(expResult);
        int result = instance.getRuntime();
        assertEquals(expResult, result);
    }

    /**
     * Test of setRuntime method, of class PopularMovie.
     */
    @Test
    public void testSetRuntime() {
        System.out.println("setRuntime");
        int runtime = 150;
        instance.setRuntime(runtime);
    }

    /**
     * Test of getDirector method, of class PopularMovie.
     */
    @Test
    public void testGetDirector() {
        System.out.println("getDirector");
        String expResult = "John Rivera";
        instance.setDirector(expResult);
        String result = instance.getDirector();
        assertEquals(expResult, result);
    }

    /**
     * Test of setDirector method, of class PopularMovie.
     */
    @Test
    public void testSetDirector() {
        System.out.println("setDirector");
        String director = "John Rivera";
        instance.setDirector(director);
    }

    /**
     * Test of getStars method, of class PopularMovie.
     */
    @Test
    public void testGetStars() {
        System.out.println("getStars");
        String expResult = "Jeff Fowler";
        instance.setStars(expResult);
        String result = instance.getStars();
        assertEquals(expResult, result);
    }

    /**
     * Test of setStars method, of class PopularMovie.
     */
    @Test
    public void testSetStars() {
        System.out.println("setStars");
        String stars = "Jeff Fowler";
        instance.setStars(stars);
    }

    /**
     * Test of getOscars method, of class PopularMovie.
     */
    @Test
    public void testGetOscars() {
        System.out.println("getOscars");
        char expResult = '2';
        instance.setOscars(expResult);
        char result = instance.getOscars();
        assertEquals(expResult, result);
    }

    /**
     * Test of setOscars method, of class PopularMovie.
     */
    @Test
    public void testSetOscars() {
        System.out.println("setOscars");
        char oscars = '2';
        instance.setOscars(oscars);
    }

    /**
     * Test of isForKids method, of class PopularMovie.
     */
    @Test
    public void testIsForKids() {
        System.out.println("isForKids");
        boolean expResult = false;
        boolean result = instance.isForKids();
        assertEquals(expResult, result);
        expResult = true;
        instance.setForKids(expResult);
        result = instance.isForKids();
        assertEquals(expResult, result);
    }

    /**
     * Test of setForKids method, of class PopularMovie.
     */
    @Test
    public void testSetForKids() {
        System.out.println("setForKids");
        boolean forKids = false;
        instance.setForKids(forKids);
    }

}
