/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.main;

import java.util.*;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovie;
import lt.viko.eif.akvietkauskaite.movie.repository.MovieRepository;
import lt.viko.eif.akvietkauskaite.movie.repository.MovieRepositoryImpl;
import lt.viko.eif.akvietkauskaite.movie.transformation.Transformer;

/**
 * The Movie program implements an application that simply displays Popular
 * Movies with Writers to the standard output.
 *
 * @author Akvilė
 */
public class Movie {
    /**
     * This is the main method which makes use of fetchAllMovies and Transformer
     * class methods.
     *
     * @param args Unused.
     */
    public static void main(String[] args) {

        MovieRepository repository = new MovieRepositoryImpl();

        List<PopularMovie> popularMovies = repository.fetchAllMovies();

        Transformer.transformToXML(popularMovies, "./movies.xml"); //failo sugeneravimui kvieciama

        List<PopularMovie> fromXml = Transformer.transformToPOJO("./movies.xml");
        System.out.println(fromXml); //POJO spausdinimui
    }
}
