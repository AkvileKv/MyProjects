/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.repository;

import java.util.List;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovie;

/**
 * Interface of Movie Repository with CRUD operations.
 *
 * @author s033783
 */
public interface MovieRepository {

    List<PopularMovie> fetchAllMovies();

    PopularMovie findOnePopularMovie(int id);

    void updateMovie(PopularMovie popularMovie);

    void deleteMovie(int id);

}
