/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Representing Popular movie.
 *
 * @author Akvilė
 */
@XmlRootElement(name = "popularMovie")
@XmlAccessorType(XmlAccessType.FIELD)
public class PopularMovie {

    /**
     * Public constant for one char representation of having an Oscar: 'W' -
     * "won Oscar".
     */
    //@XmlAttribute
    public static final char WON_OSCARS = 'W'; // konstantos

    /**
     * Public constant for one char representation of not having an Oscar: 'W' -
     * "no Oscar".
     */
    public static final char NO_OSCARS = 'N';

    /**
     * Public constant for boolean type representation that is attributed to a
     * children's movie.
     */
    public static final boolean KIDS = true;
    /**
     * Public constant for boolean type representation that is attributed to a
     * adult's movie.
     */
    public static final boolean ADULTS = false;

    @XmlAttribute
    private String title;
    private String category;
    private String releaseDate;
    private String IMDB;
    private int runtime;
    private String director;
    private String stars;
    @XmlJavaTypeAdapter(CharacterAdapter.class)
    private Character oscars;
    private boolean forKids;
    @XmlElement(name = "writer")
    private List<Writer> writerList = new ArrayList();  //import util.List and util.ArrayList
    @XmlAttribute
    private int id;

    /**
     * The PopularMovie constructor.
     *
     * @param title String type (required) title of this Movie.
     * @param category String type (required) category of this Movie.
     * @param releaseDate String type (required) release date of this Popular
     * Movie.
     * @param IMDB String type (required) IMDB score of this Movie.
     * @param runtime integer type (required) runtime of this Movie.
     * @param director String type (required) director of the Movie.
     * @param stars String type (required) stars of the Movie.
     * @param oscars Character type (required) This Popular Movie won an Oscar
     * or not.
     * @param forKids Boolean type (required) Movie is for kids or not.
     * @param id integer type(required) Movie ID number.
     */
    public PopularMovie(String title, String category, String releaseDate,
            String IMDB, int runtime, String director, String stars, char oscars,
            boolean forKids, int id) {
        this.title = title;
        this.category = category;
        this.releaseDate = releaseDate;
        this.IMDB = IMDB;
        this.runtime = runtime;
        this.director = director;
        this.stars = stars;
        this.oscars = oscars;
        this.forKids = forKids;
        this.id = id;
    }

    /**
     * The string representation is "title=TITLE, category=CATEGORY", etc. Where
     * TITLE is the Movie title and CATEGORY is the Movie category, etc.
     *
     * @return String type Movie description including Writers description.
     */
    @Override
    public String toString() {
        return "\nPopular Movie{" + "\n TITLE = "
                + title + ",\n CATEGORY = "
                + category + ",\n RELASE DATE = "
                + releaseDate + ",\n IMDB = "
                + IMDB + ",\n RUNTIME = "
                + runtime + ",\n DIRECTOR = "
                + director + ",\n STARS = "
                + stars + ",\n OSCARS = "
                + oscars + ",\n FOR KIDS = "
                + forKids + ",\n WRITER LIST = "
                + writerList + '}';
    }

    /**
     * Default constructor.
     */
    public PopularMovie() {

    }

    /**
     * Gets the ID number of this Movie.
     *
     * @return integer type Movie ID number
     */
    public int getId() {
        return id;
    }

    /**
     * Assign the ID number of this Movie.
     *
     * @param id integer type This Movie's ID number
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the Writer list of this Movie.
     *
     * @return List type The list of movie writer
     */
    public List<Writer> getWriterList() {
        return writerList;
    }

    /**
     * Assign the Writer list of this Movie.
     *
     * @param writerList List type This Movie's Writer list
     */
    public void setWriterList(List<Writer> writerList) {
        this.writerList = writerList;
    }

    /**
     * Gets the title of this Movie.
     *
     * @return String type Movie title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Assign the title of this Movie.
     *
     * @param title String type This Movie's title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the category of this Movie.
     *
     * @return String type Movie category
     */
    public String getCategory() {
        return category;
    }

    /**
     * Assign the category of this Movie.
     *
     * @param category String type This Movie's category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Gets the release date of this Movie.
     *
     * @return String type Movie release date
     */
    public String getReleaseDate() {
        return releaseDate;
    }

    /**
     * Assign the release date of this Movie.
     *
     * @param releaseDate String type This Movie's release date
     */
    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    /**
     * Gets the IMDB score of this Movie.
     *
     * @return String type Movie IMDB score
     */
    public String getIMDB() {
        return IMDB;
    }

    /**
     * Assign the IMDB score of this Movie.
     *
     * @param IMDB String type This Movie's IMDB score
     */
    public void setIMDB(String IMDB) {
        this.IMDB = IMDB;
    }

    /**
     * Gets the runtime of this Movie.
     *
     * @return integer type Movie runtime
     */
    public int getRuntime() {
        return runtime;
    }

    /**
     * Assign the runtime of this Movie.
     *
     * @param runtime String type This Movie's runtime
     */
    public void setRuntime(int runtime) {
        this.runtime = runtime;
    }

    /**
     * Gets the director of this Movie.
     *
     * @return String type Movie Director
     */
    public String getDirector() {
        return director;
    }

    /**
     * Assign the Director of this Movie.
     *
     * @param director String type This Movie's Director
     */
    public void setDirector(String director) {
        this.director = director;
    }

    /**
     * Gets the Stars of this Movie.
     *
     * @return String type Movie Stars
     */
    public String getStars() {
        return stars;
    }

    /**
     * Assign the Stars of this Movie.
     *
     * @param stars String type This Movie's Stars
     */
    public void setStars(String stars) {
        this.stars = stars;
    }

    /**
     * Gets the Oscar of this Movie.
     *
     * @return Character type Movie Oscar
     */
    //@XmlJavaTypeAdapter(CharacterAdapter.class)
    public Character getOscars() {
        return oscars;
    }

    /**
     * Assign the Oscar of this Movie.
     *
     * @param oscars Character type This Movie's Oscar.
     */
    public void setOscars(char oscars) {
        this.oscars = oscars;
    }

    /**
     * Gets is this Movie For Kids or not.
     *
     * @return boolean type Movie is For Kids or not
     */
    public boolean isForKids() {
        return forKids;
    }

    /**
     * Assign is this Movie For Kids or not.
     *
     * @param forKids boolean type This Movie is for kids or adults
     */
    public void setForKids(boolean forKids) {
        this.forKids = forKids;
    }

}
