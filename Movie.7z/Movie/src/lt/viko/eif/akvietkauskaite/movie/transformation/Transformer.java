/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.transformation;

import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import javax.xml.bind.PropertyException;
import javax.xml.bind.Unmarshaller;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovie;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovieList;

/**
 * Representing transformations from and to XML.
 *
 * @author Akvilė
 */
public class Transformer {

    /**
     * Method representing transformation from POJO to XML.
     *
     * @param popularMovies List of popular movies.
     * @param filePath Path to the location where the file was created.
     */
    public static void transformToXML(List<PopularMovie> popularMovies, String filePath) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(PopularMovieList.class); //Create JAXB Context
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();  //Create Marshaller

            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true); // To format XML

            PopularMovieList list = new PopularMovieList(popularMovies); //list - vientisam gauti

            File file = new File(filePath);

            if (!file.exists()) {
                file.createNewFile();
            }
            //Print XML String to Console
            //jaxbMarshaller.marshal(list, System.out);
            jaxbMarshaller.marshal(list, file);
        } catch (JAXBException | IOException ex) {
            ex.printStackTrace(); // parodo paskutini veikianti stack
        }
    }

    /**
     * Method representing transformation from XML to POJO.
     *
     * @param filePath Path to the location where the file is.
     * @return list.getContents() Content of movies with writers
     */
    public static List<PopularMovie> transformToPOJO(String filePath) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(PopularMovieList.class); //Create JAXB Context
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  //Create Marshaller

            //Print XML String to Console
            //jaxbMarshaller.marshal(list, System.out);
            PopularMovieList list = (PopularMovieList) jaxbUnmarshaller.unmarshal(new File(filePath));
            return list.getContents(); //grazina turini
        } catch (JAXBException ex) {
            ex.printStackTrace(); // klaidu radimui, parodo paskutini veikianti stack
            return null;
        }
    }

}
