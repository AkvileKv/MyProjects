/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Class representing content creation for all Popular movies.
 *
 * @author Akvilė
 */
@XmlRootElement(name = "movies")
public class PopularMovieList { //be jos nebutu vientiso saraso

    @XmlElement(name = "movie", type = PopularMovie.class)
    private List<PopularMovie> contents = new ArrayList<>();

    public PopularMovieList() {
    }

    public PopularMovieList(List<PopularMovie> contents) {
        this.contents.addAll(contents);
    }

    public List<PopularMovie> getContents() {
        return contents; //grazina i main turini
    }

}
