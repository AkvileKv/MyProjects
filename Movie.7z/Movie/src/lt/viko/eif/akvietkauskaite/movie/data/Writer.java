/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Represents a writer enrolled in the popular movie.
 *
 * @author Akvilė
 */
@XmlRootElement(name = "writer")
@XmlAccessorType(XmlAccessType.FIELD)
public class Writer {

    private String name;
    private String surname;
    private int oscarsCount;
    private int wins;
    private int nominations;

    /**
     * Gets the first name of this Writer.
     *
     * @return String type
     * This Writer's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Assign the first name of this Writer.
     *
     * @param name 
     * This Writer's name.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the last name of this Writer.
     *
     * @return String type
     * This Writer's surname.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Assign the last name of this Writer.
     *
     * @param surname 
     * This Writer's surname.
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Gets the Oscar number of this Writer.
     *
     * @return integer type 
     * This Writer's Oscar number.
     */
    public int getOscarsCount() {
        return oscarsCount;
    }

    /**
     * Assign the Oscar number of this Writer.
     *
     * @param oscarsCount 
     * This Writer's Oscar number.
     */
    public void setOscarsCount(int oscarsCount) {
        this.oscarsCount = oscarsCount;
    }

    /**
     * Gets the wins number of this Writer.
     *
     * @return integer type 
     * Number of writer wins/achievements.
     */
    public int getWins() {
        return wins;
    }

    /**
     * Assign the wins number of this Writer.
     *
     * @param wins 
     * Number of writer wins/achievements.
     */
    public void setWins(int wins) {
        this.wins = wins;
    }

    /**
     * Gets the nominations number of this Writer.
     *
     * @return integer type 
     * Number of writer wins/achievements.
     */
    public int getNominations() {
        return nominations;
    }

    /**
     * Assign the nominations number of this Writer.
     *
     * @param nominations 
     * Number of writer nominations.
     */
    public void setNominations(int nominations) {
        this.nominations = nominations;
    }

    /**
     * The string representation is "name=name, surname=surname", etc. Where
     * name is the Writer name and surname is the Writer surname, etc.
     *
     * @return String type
     * Writer description.
     */
    @Override
    public String toString() {
        return "\n\tWriter {" + "name = "
                + name + "" + ", surname = "
                + surname + "" + ", oscarsCount = "
                + oscarsCount + "" + ", wins = "
                + wins + "" + ", nominations = "
                + nominations + "" + '}';
    }
}
