/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.viko.eif.akvietkauskaite.movie.repository;

import java.util.LinkedList;
import java.util.List;
import lt.viko.eif.akvietkauskaite.movie.data.PopularMovie;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.ADULTS;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.KIDS;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.NO_OSCARS;
import static lt.viko.eif.akvietkauskaite.movie.data.PopularMovie.WON_OSCARS;
import lt.viko.eif.akvietkauskaite.movie.data.Writer;

/**
 * A composite type class that implements the MovieRepository interface.
 *
 * @author Akvilė
 */
public class MovieRepositoryImpl implements MovieRepository {
// klase sudetinio tipo (abieju tipu yra)
//su MovieRepositoryImpl klase, kuri realizuoja MovieRepository interface'e

    private static List<PopularMovie> popularMovies = new LinkedList<>();

    static {
        Writer writer_1 = new Writer();
        writer_1.setName("Quentin Jerome");
        writer_1.setSurname("Tarantino");
        writer_1.setOscarsCount(2);
        writer_1.setWins(162);
        writer_1.setNominations(266);

        Writer writer_2 = new Writer();
        writer_2.setName("Taika");
        writer_2.setSurname("Waititi");
        writer_2.setOscarsCount(1);
        writer_2.setWins(69);
        writer_2.setNominations(79);

        Writer writer_3 = new Writer();
        writer_3.setName("Christine");
        writer_3.setSurname("Leunens");
        writer_3.setOscarsCount(0);
        writer_3.setWins(0);
        writer_3.setNominations(2);

        Writer writer_4 = new Writer();
        writer_4.setName("Patrick");
        writer_4.setSurname("Casey");
        writer_4.setOscarsCount(0);
        writer_4.setWins(1);
        writer_4.setNominations(2);

        Writer writer_5 = new Writer();
        writer_5.setName("Rian");
        writer_5.setSurname("Johnson");
        writer_5.setOscarsCount(1);
        writer_5.setWins(34);
        writer_5.setNominations(68);

        Writer writer_6 = new Writer();
        writer_6.setName("Josh");
        writer_6.setSurname("Miller");
        writer_6.setOscarsCount(0);
        writer_6.setWins(2);
        writer_6.setNominations(5);

        PopularMovie movie = new PopularMovie(); //create an object of type PopularMovie
        movie.getWriterList().add(writer_1);

        movie.setTitle("Once Upon a Time ...in Hollywood");
        movie.setCategory("Comedy, Drama");
        movie.setReleaseDate("16 August 2019");
        movie.setIMDB("7.7");
        movie.setRuntime(161);
        movie.setDirector("Quentin Tarantino");
        movie.setStars("Leonardo DiCaprio, Brad Pitt, Margot Robbie, Emile Hirsch");
        movie.setOscars(WON_OSCARS);
        movie.setForKids(ADULTS);
        movie.setId(1);

        PopularMovie movie_1 = new PopularMovie("Jojo Rabbit", " Comedy, Drama",
                "2020", "8.0", 108, "Taika Waititi", "Roman Griffin Davis, Thomasin McKenzie",
                WON_OSCARS, KIDS, 2);
        movie_1.getWriterList().add(writer_2);
        movie_1.getWriterList().add(writer_3);

        PopularMovie movie_2 = new PopularMovie("Sonic the Hedgehog", "Action, Adventure",
                "2020", "6.9", 99, " Jeff Fowler", "Ben Schwartz, James Marsden", WON_OSCARS, KIDS, 3);
        movie_2.getWriterList().add(writer_4);
        movie_2.getWriterList().add(writer_6);

        PopularMovie movie_3 = new PopularMovie("Knives Out", "Comedy, Crime", "2019",
                "8.0", 131, "Rian Johnson", " Daniel Craig, Chris Evans", NO_OSCARS, ADULTS, 4);
        movie_3.getWriterList().add(writer_5);

        popularMovies.add(movie);
        popularMovies.add(movie_1);
        popularMovies.add(movie_2);
        popularMovies.add(movie_3);
    }

    /**
     * For returning the Movie list.
     *
     * @return the list of all popular movies.
     */
    @Override
    public List<PopularMovie> fetchAllMovies() {
        return popularMovies;
    }

    /**
     * Movie search by id.
     *
     * @param id
     * @return Movie by ID or null value.
     */
    @Override
    public PopularMovie findOnePopularMovie(int id) {
        for (PopularMovie movie : popularMovies) {
            if (movie.getId() == id) {
                return movie;
            }
        }
        return null;
    }

    @Override
    public void updateMovie(PopularMovie popularMovie) {

    }

    @Override
    public void deleteMovie(int id) {
        try {
            popularMovies.remove(findOnePopularMovie(id));
        } catch (Exception ex) {

            System.out.println("Can't find movie with ID");
        }
    }
    /*      for (PopularMovie movie : popularMovies) {
            if (movie.getId() == id) {
               popularMovies.remove(id); //pereiti per visa list, rasti obj su id pozicija, tada galim istrinti;
               
               for(String var: popularMovies){
            System.out.println(var);
       }
     */

}
