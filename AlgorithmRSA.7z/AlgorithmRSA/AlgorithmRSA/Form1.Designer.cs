﻿namespace AlgorithmRSA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DecryptionGroupBox = new System.Windows.Forms.GroupBox();
            this.testTextBox = new System.Windows.Forms.TextBox();
            this.EncryptedTextLabel = new System.Windows.Forms.Label();
            this.DecryptedTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.EncryptionGroupBox = new System.Windows.Forms.GroupBox();
            this.TextForEncryptionTextBox = new System.Windows.Forms.TextBox();
            this.TextForEncryptionLabel = new System.Windows.Forms.Label();
            this.ResetButton = new System.Windows.Forms.Button();
            this.EncryptButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.DecryptionGroupBox.SuspendLayout();
            this.EncryptionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // DecryptionGroupBox
            // 
            this.DecryptionGroupBox.Controls.Add(this.label1);
            this.DecryptionGroupBox.Controls.Add(this.testTextBox);
            this.DecryptionGroupBox.Controls.Add(this.label2);
            this.DecryptionGroupBox.Location = new System.Drawing.Point(12, 198);
            this.DecryptionGroupBox.Name = "DecryptionGroupBox";
            this.DecryptionGroupBox.Size = new System.Drawing.Size(594, 104);
            this.DecryptionGroupBox.TabIndex = 48;
            this.DecryptionGroupBox.TabStop = false;
            this.DecryptionGroupBox.Text = "Decryption";
            // 
            // testTextBox
            // 
            this.testTextBox.Location = new System.Drawing.Point(131, 56);
            this.testTextBox.Name = "testTextBox";
            this.testTextBox.Size = new System.Drawing.Size(431, 20);
            this.testTextBox.TabIndex = 50;
            // 
            // EncryptedTextLabel
            // 
            this.EncryptedTextLabel.AutoSize = true;
            this.EncryptedTextLabel.Location = new System.Drawing.Point(46, 118);
            this.EncryptedTextLabel.Name = "EncryptedTextLabel";
            this.EncryptedTextLabel.Size = new System.Drawing.Size(78, 13);
            this.EncryptedTextLabel.TabIndex = 49;
            this.EncryptedTextLabel.Text = "Encrypted text:";
            // 
            // DecryptedTextBox
            // 
            this.DecryptedTextBox.Location = new System.Drawing.Point(131, 115);
            this.DecryptedTextBox.Name = "DecryptedTextBox";
            this.DecryptedTextBox.Size = new System.Drawing.Size(431, 20);
            this.DecryptedTextBox.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 36;
            // 
            // EncryptionGroupBox
            // 
            this.EncryptionGroupBox.Controls.Add(this.TextForEncryptionTextBox);
            this.EncryptionGroupBox.Controls.Add(this.EncryptedTextLabel);
            this.EncryptionGroupBox.Controls.Add(this.TextForEncryptionLabel);
            this.EncryptionGroupBox.Controls.Add(this.DecryptedTextBox);
            this.EncryptionGroupBox.Controls.Add(this.ResetButton);
            this.EncryptionGroupBox.Controls.Add(this.EncryptButton);
            this.EncryptionGroupBox.Location = new System.Drawing.Point(12, 12);
            this.EncryptionGroupBox.Name = "EncryptionGroupBox";
            this.EncryptionGroupBox.Size = new System.Drawing.Size(594, 164);
            this.EncryptionGroupBox.TabIndex = 47;
            this.EncryptionGroupBox.TabStop = false;
            this.EncryptionGroupBox.Text = "Encryption";
            // 
            // TextForEncryptionTextBox
            // 
            this.TextForEncryptionTextBox.Location = new System.Drawing.Point(131, 36);
            this.TextForEncryptionTextBox.Name = "TextForEncryptionTextBox";
            this.TextForEncryptionTextBox.Size = new System.Drawing.Size(431, 20);
            this.TextForEncryptionTextBox.TabIndex = 33;
            // 
            // TextForEncryptionLabel
            // 
            this.TextForEncryptionLabel.AutoSize = true;
            this.TextForEncryptionLabel.Location = new System.Drawing.Point(25, 39);
            this.TextForEncryptionLabel.Name = "TextForEncryptionLabel";
            this.TextForEncryptionLabel.Size = new System.Drawing.Size(98, 13);
            this.TextForEncryptionLabel.TabIndex = 35;
            this.TextForEncryptionLabel.Text = "Text for encryption:";
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(352, 62);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(102, 23);
            this.ResetButton.TabIndex = 42;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // EncryptButton
            // 
            this.EncryptButton.Location = new System.Drawing.Point(460, 62);
            this.EncryptButton.Name = "EncryptButton";
            this.EncryptButton.Size = new System.Drawing.Size(102, 23);
            this.EncryptButton.TabIndex = 39;
            this.EncryptButton.Text = "Encrypt";
            this.EncryptButton.UseVisualStyleBackColor = true;
            this.EncryptButton.Click += new System.EventHandler(this.EncryptButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Decrypted text:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 325);
            this.Controls.Add(this.DecryptionGroupBox);
            this.Controls.Add(this.EncryptionGroupBox);
            this.Name = "Form1";
            this.Text = "RSA Algorithm";
            this.DecryptionGroupBox.ResumeLayout(false);
            this.DecryptionGroupBox.PerformLayout();
            this.EncryptionGroupBox.ResumeLayout(false);
            this.EncryptionGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox DecryptionGroupBox;
        private System.Windows.Forms.Label EncryptedTextLabel;
        private System.Windows.Forms.TextBox DecryptedTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox EncryptionGroupBox;
        private System.Windows.Forms.TextBox TextForEncryptionTextBox;
        private System.Windows.Forms.Label TextForEncryptionLabel;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button EncryptButton;
        private System.Windows.Forms.TextBox testTextBox;
        private System.Windows.Forms.Label label1;
    }
}

