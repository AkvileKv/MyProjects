﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace AlgorithmRSA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            generateKeys(); //generuoju raktus
        }
        
        private static RSAParameters privateKey;
        private static RSAParameters publicKey;

        private void EncryptButton_Click(object sender, EventArgs e)
        {

            if (TextForEncryptionTextBox.Text == string.Empty)
            {
                MessageBox.Show("Please fill in field");
                return;
            }
            else
            {             
                byte[] encrypted = Encrypt(Encoding.ASCII.GetBytes(TextForEncryptionTextBox.Text));
                byte[] decrypted = Decrypt(encrypted);

                DecryptedTextBox.Text = BitConverter.ToString(encrypted);

                MessageBox.Show("Text was successfully encrypted");
                MessageBox.Show("Do you want to Decrypt it?");           

                TextForEncryptionTextBox.Clear();

                testTextBox.Text = Encoding.ASCII.GetString(decrypted);
                MessageBox.Show("Text was successfully decrypted");          
                return;                        
            }
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            TextForEncryptionTextBox.Clear();
            testTextBox.Clear();
            DecryptedTextBox.Clear();
        }

        static void generateKeys()
        {
            using (var rsa = new RSACryptoServiceProvider(2048)) //naudoju 2048 bit rakta
            {
                rsa.PersistKeyInCsp = false; // nesaugau konteineryje raktu
                publicKey = rsa.ExportParameters(false); 
                privateKey = rsa.ExportParameters(true); //objektas, grazina kaip parametra
            }
        }

        static byte[] Encrypt(byte[] input)
        {
            byte[] encrypted;

            using (var rsa = new RSACryptoServiceProvider(2048))
            {
                rsa.PersistKeyInCsp = false;
                rsa.ImportParameters(publicKey); //Importuoju anksciau sukurta rakta
                encrypted = rsa.Encrypt(input, true); //Enkriptinu
            }
            return encrypted; //bus grazintas kaip byte masyvas
        }

        static byte[] Decrypt(byte[] input)
        {
            byte[] decrypted;
            
            using (var rsa = new RSACryptoServiceProvider(2048))
            {
                rsa.PersistKeyInCsp = false;
                rsa.ImportParameters(privateKey); //Importuoju anksciau sukurta rakta
                decrypted = rsa.Decrypt(input, true); //Dekriptinu
            }
            return decrypted; //bus grazintas kaip byte masyvas
        }
    }
}
