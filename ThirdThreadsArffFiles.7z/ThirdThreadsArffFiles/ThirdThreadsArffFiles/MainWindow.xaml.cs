﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Interop;
using MessageBox = System.Windows.MessageBox;

namespace ThirdThreadsArffFiles
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string fileLastLine = "C:\\Users\\Akvilė\\Desktop\\ArffResultFile.txt";

        [DllImport("user32.dll")]
        static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);
        [DllImport("user32.dll")]
        static extern bool EnableMenuItem(IntPtr hMenu, uint uIDEnableItem, uint uEnable);
        const uint MF_BYCOMMAND = 0x00000000;
        const uint MF_GRAYED = 0x00000001;
        const uint SC_CLOSE = 0xF060;

        public MainWindow()
        {
            InitializeComponent();

            string[] Criteria = File.ReadAllLines("C:\\Users\\Akvilė\\Desktop\\CriteriaList.txt");
            ArrayList list = new ArrayList(Criteria);
            CriteriaListBox.ItemsSource = list;

            InvisibleListBox.Visibility = Visibility.Collapsed;
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            // Disable close button
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            IntPtr hMenu = GetSystemMenu(hwnd, true);
            if (hMenu != IntPtr.Zero)
            {
                EnableMenuItem(hMenu, SC_CLOSE, MF_BYCOMMAND | MF_GRAYED);
            }
        }
        

        private void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog fBrowserD = new FolderBrowserDialog(); //select: using System ....
            DialogResult searchingResult = fBrowserD.ShowDialog();
            StartPointNameTextBox.Text = fBrowserD.SelectedPath; //laukas igauna pasirinkto kelio reiksme 
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            ResultListView.Items.Clear();
            FileNameTextBox.Clear();
            StartPointNameTextBox.Clear();
            ProgressBar.Value = 0;
            SelectedCriteriaListBox.Items.Clear();
            InvisibleListBox.Items.Clear();

            File.WriteAllText(fileLastLine, String.Empty);

            OnSourceInitialized(e);
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            // Disable close button
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            IntPtr hMenu = GetSystemMenu(hwnd, false);
            if (hMenu != IntPtr.Zero)
            {
                EnableMenuItem(hMenu, SC_CLOSE, MF_BYCOMMAND | MF_GRAYED);
            } 
            //------------------------------------------------------------------

            ResultListView.Items.Clear(); //isvalau rezultatus

            if (FileNameTextBox.Text == "" || StartPointNameTextBox.Text == "")//ar laukai ne tusti
            {
                MessageBox.Show("Please fill in all fields");
                return;
            }
            if (!Directory.Exists(StartPointNameTextBox.Text)) //ar egzistuoja direktorija
            {
                MessageBox.Show("Selected directory does not exist...");
                return;
            }
            if (SelectedCriteriaListBox.Items.Count <= 0) 
            {          
                MessageBox.Show("Please select criteria");
                return;
            }
            // ----------------I rezultatu faila irasau----------------------------
            StreamWriter File = new StreamWriter(fileLastLine, true);
            File.Write("@relation SMILEfeatures\r\n\n");

            string[] indexArray = new string[SelectedCriteriaListBox.Items.Count];

            for (int i = 0; i < SelectedCriteriaListBox.Items.Count; i++)
            {
               indexArray[i] = SelectedCriteriaListBox.Items[i].ToString();  //Konvertuoja string array i integer array
               File.Write(indexArray[i] + Environment.NewLine);
            }
            File.Write("\r\n");
            File.Write("@data\r\n\n");
            File.Close();    
            

            //------------- FAILU paieskai--------------------------------

            ResultListView.Visibility = Visibility.Visible;

                List<string> list1 = SearchingForThemFiles(StartPointNameTextBox.Text); //pereina per visus (kiek is viso failu yra tenai)
                Search toSearch = new Search(FileNameTextBox, StartPointNameTextBox, ResultListView,
                               ProgressBar, list1, InvisibleListBox);

                Thread th = new Thread(new ThreadStart(toSearch.GetFiles)); //Kuriama gija failu paieskai vykdymui, deleguojamas metodas                                                                           
                th.Start();                     
        }

        //-------------pereina per visus FAILUS--------------
        static public List<string> SearchingForThemFiles(string path1) //ieskant failu
        {
            List<string> resultList = new List<string>(); //sukuriamas rezultatu list'as string tipo 
            string pathh = "";

            try
            {
                foreach (var item in Directory.GetFiles(path1)) //pradzios direktorijoj failu ieskoti
                {
                    resultList.Add(item); //pridedu i resultList rastus
                }
                foreach (var item in Directory.GetDirectories(path1)) //subdirektoriju vardai direktorijoj
                {
                    foreach (var file in SearchingForFiles(item)) //subdirektorijose ieskoti failu
                    {
                        resultList.Add(file); //pridedu i resultList rastus
                    }
                    pathh = item; //subdirektoriju vardai tampa pathh
                }

                foreach (var item in Directory.GetDirectories(pathh)) //subdirektoriju vardai direktorijoj
                {
                    foreach (var file in SearchingForFiles(item))  //subdirektorijose ieskoti failu
                    {
                        resultList.Add(file); //pridedu i resultList rastus
                    }
                }
            }
            catch (Exception)
            {
            }
            return resultList;
        }

        static public List<string> SearchingForFiles(string path1) //subdirektorijose ieskoti failu
        {
            List<string> resultList = new List<string>();

            try
            {
                foreach (var item in Directory.GetFiles(path1))  //visu failu ieskoti
                {
                    resultList.Add(item); //pridedu i resultList rastus
                }
            }

            catch (Exception)
            {
            }
            return resultList;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (CriteriaListBox.SelectedItem != null)
            { 
                var currentItemText = CriteriaListBox.SelectedValue.ToString(); 
                var currentItemIndex = CriteriaListBox.SelectedIndex;        //priskiria indeksa kiekvienai reiksmei nuo 0; 
                SelectedCriteriaListBox.Items.Add(currentItemText);         //prideda i SelectedCriteriaListBox pagal teksta;
                InvisibleListBox.Items.Add(currentItemIndex); //indeksams saugoti
            }
            else
                MessageBox.Show("Please select criteria");
            return;
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedCriteriaListBox.SelectedItem != null)
            {
                SelectedCriteriaListBox.Items.RemoveAt(SelectedCriteriaListBox.Items.IndexOf(SelectedCriteriaListBox.SelectedItem)); //panaikina reiksme ir indeksa is SelectedCriteriaListBox
            }
            else
                MessageBox.Show("Please select criteria");
            return;
        }

        private void CriteriaListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
