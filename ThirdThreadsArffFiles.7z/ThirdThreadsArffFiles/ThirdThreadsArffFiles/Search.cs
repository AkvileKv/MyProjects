﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace ThirdThreadsArffFiles
{
    class Search
    {

        ManualResetEvent resetEvent = new ManualResetEvent(true);

        string filePathMD5 = "C:\\Users\\Akvilė\\Desktop\\FileMD5.txt";
        string fileLastLine = "C:\\Users\\Akvilė\\Desktop\\ArffResultFile.txt";
        TextBox FileNameTextBox;
        TextBox StartPointNameTextBox;
        ListView ResultListView;       
        ProgressBar ProgressBar;
        List<string> list1 = new List<string>();
        ListBox InvisibleListBox;


        public Search(TextBox fileNameTextBox, TextBox startPointNameTextBox,ListView resultListView, 
            ProgressBar progressBar, List<string> list1, ListBox InvisibleListBox)
        {
            FileNameTextBox = fileNameTextBox;
            StartPointNameTextBox = startPointNameTextBox;
            ResultListView = resultListView;          
            ProgressBar = progressBar;
            this.list1 = list1;  
            this.InvisibleListBox = InvisibleListBox;
        }

        public void GetFiles()
        {
            ResultListView.Dispatcher.Invoke(() =>             //rodykline anonimine f-ja. Sukuriamas metodas
            {                                                  //Dispatcher-darbui su gijomis valdyti, prioritetiniam ju darbui. Invoke - vykdoma nedelsiant
                var chronometer = new Stopwatch();
                MessageBox.Show("Total files found: " + list1.Count.ToString());
                chronometer.Start();

                ProgressBar.Value = 0;
                ProgressBar.Maximum = list1.Count;  //listo su rastais failais
                ProgressBar.Visibility = Visibility.Visible;

                FileSearching(StartPointNameTextBox.Text, ProcessFile, list1); //paieska vykdoma
                chronometer.Stop(); //baigesi paieska, sustoja chronometras 

                //MessageBox.Show("Execution was successfully");
                var elapsedTime = chronometer.ElapsedMilliseconds;
                MessageBox.Show("Execution time: " + (elapsedTime / 1).ToString() + " ms");

            });
        }

        static void ProcessFile(string path) { }

        //----------------------bendram liste1 iesko mano FAILO---------------
        public void FileSearching(string path1, Action<string> fAction, List<string> list1)
        {
            foreach (var item in Directory.GetFiles(path1))  //pradzios direktorijoj failu ieskoti
            {
                try
                {
                    ResultListView.Dispatcher.Invoke(() =>                //rodykline anonimine f-ja. Sukuriamas metodas
                    {                                                    //Dispatcher-darbui su gijomis valdyti, prioritetiniam ju darbui. Invoke - vykdoma nedelsiant

                        if (list1.Contains(item))   //Ar ieskomas failas yra list1'e
                        {
                            ProgressBar.Dispatcher.Invoke(() =>
                            ProgressBar.Value++, DispatcherPriority.Background);
                        }                                                             //DispatcherPriority - Describes the priorities at which operations can be invoked by way of the Dispatcher;
                                                                                      //Background - Operations are processed after all other non-idle operations are completed.

                        if (item.EndsWith(FileNameTextBox.Text)) // Rado 
                        {                                                                                        
                               //HashMD5(item); //iraso MD5 Hash i faila     
                               
                               FindHashMD5(item); //Strukturos tikrinimui
                            
                            Information information = new Information(item); //kai tik randa faila, pasirodo resultList'e
                            AddToList add = new AddToList(ResultListView, information);


                            Thread th = new Thread(add.ListAdd);    //kuriama gija duomenu atvaizdavimui ir isvedimui. 
                            th.Start();                            //Metodas deleguojamas gijai
                        }
                    });

                }
                catch (Exception)
                {
                }
                fAction(item);
            }
            foreach (var item in Directory.GetDirectories(path1)) //subdirektoriju vardai direktorijoj
            {
                try
                {
                    FileSearching(item, fAction, list1); //rekursiškai kreipiasi i save, paieška subkategorijose
                }
                catch (Exception)
                {
                }
            }
        }

        private static Action EmptyDelegate = delegate () { }; //-----------------AR REIKIA MAN JO ???-----------------------

        //------------------------------------MD5 hash-----------------------------------------------------------
        private void HashMD5(string item) // MD5 Hash apskaiciuoja ir iraso i faila
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(item));
            byte[] textBytes = md5.ComputeHash(File.ReadAllBytes(item)); //byte nuskaitymui is failo

            StringBuilder str = new StringBuilder();
            for (int i = 0; i < textBytes.Length; i++)
            {
                str.Append(textBytes[i].ToString("x2"));
            }
            StreamWriter toFile = new StreamWriter(filePathMD5, true); //kad pridetu teksta, o ne perrasytu
            toFile.Write(str.ToString() + "\n");
            toFile.Close();
        }

        private void FindHashMD5(string item) // MD5 Hash apskaiciavimui ir palyginimui
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(item));
            byte[] textBytes = md5.ComputeHash(File.ReadAllBytes(item)); //byte nuskaitymui is failo

            StringBuilder str = new StringBuilder();
            for (int i = 0; i < textBytes.Length; i++)
            {
                str.Append(textBytes[i].ToString("x2"));
            }
            string md5Value = str.ToString();

            //---------paieska FileMD5 faile ir lyginimas------
            foreach (var line in File.ReadAllLines(filePathMD5))
            {
                if (line.Contains(md5Value))
                {                                               
                    FindCriteriaValue(item);  //SUTAMPA: ima is paskutines eilutes reiksme pagal indeksa 
                }
                else
                {

                }
            }
        }

        private void FindCriteriaValue(string item)
        {      
            string valueLine = File.ReadLines(item).Skip(6560).Take(1).First(); //praleidzia() eilutes, paima() eilute; (6560)6556
            string[] value = valueLine.Split(','); //ima kas kableli reiksme

            int[] indexArray = new int[InvisibleListBox.Items.Count];

            for (int i = 0; i < InvisibleListBox.Items.Count; i++)
            {
                indexArray[i] = Convert.ToInt32(InvisibleListBox.Items[i].ToString()); //Konvertuoja string array i integer array
                File.AppendAllText(fileLastLine, value[indexArray[i]] + ",");                             
            }
            File.AppendAllText(fileLastLine, Environment.NewLine); //padaro nauja eilute kitam rezultatui
        }
    }
}
