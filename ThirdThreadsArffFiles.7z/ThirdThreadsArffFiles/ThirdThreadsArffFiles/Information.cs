﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThirdThreadsArffFiles
{
    class Information
    {
        private string path;

        public Information(string path) //konstruktorius
        {
            this.path = path;
        }

        public string Path
        {
            get { return path; }
            set { path = value; }
        }
    }
}
